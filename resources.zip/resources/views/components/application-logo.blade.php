<img class="w-20" src="{{asset('assets/icon.png')}}" />
