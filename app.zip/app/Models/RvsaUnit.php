<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RvsaUnit extends Model
{
    use HasFactory;
    protected $fillable = ['title','responsible_person','contact_phone','contact_email'];
}
