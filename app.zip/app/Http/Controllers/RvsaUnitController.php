<?php

namespace App\Http\Controllers;

use App\Models\RvsaUnit;
use Illuminate\Http\Request;
use DataTables;

class RvsaUnitController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $units = RvsaUnit::all();

            return DataTables::of($units)
                ->addColumn('actions', function ($unit) {
                    return '';
                })
                ->rawColumns(['action'])
                ->make('true');
        }

        return view('rvsa_units.index');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate([

            'title' =>'required',
            'responsible_person'  => 'required',
            'contact_phone' =>'required',
            'contact_email' =>'required'

        ]);

        $unit = RvsaUnit::create([
                'title' => $request->title,
                'responsible_person' => $request->responsible_person,
                'contact_phone' => $request->responsible_person,
                'contact_email' => $request->contact_email
        ]);

        return redirect('/rvsa-units')->with('success', 'RVSA unit added successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, RvsaUnit $unit)
    {
        request()->validate([

            'title' =>'required',
            'responsible_person'  => 'required',
            'contact_phone' =>'required',
            'contact_email' =>'required'

        ]);

        $unit->update([
            'title' => $request->title,
            'responsible_person' => $request->responsible_person,
            'contact_phone' => $request->responsible_person,
            'contact_email' => $request->contact_email
        ]);

        return redirect('/rvsa-units')->with('success', 'RVSA unit updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(RvsaUnit $unit)
    {
        $unit->delete();

        return redirect('/rvsa-units')->with('success', 'RVSA unit removed successfully');
    }

    public function edit(RvsaUnit $unit)
    {
        return view('rvsa_units.edit', compact('unit'));
    }

    public function create()
    {
        return view('rvsa_units.create');
    }
}
