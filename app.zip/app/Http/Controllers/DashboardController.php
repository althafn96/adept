<?php

namespace App\Http\Controllers;

use App\Models\District;
use App\Models\Member;
use App\Models\Specialization;
use App\Models\Vertical;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function __invoke()
    {
        $members = Member::where('status', '1')->get()->count();
        $verticals = Vertical::where('status', '1')->get()->count();
        $specializations = Specialization::where('status', '1')->get()->count();
        $areas = District::where('status', '1')->get()->count();

        return view('dashboard', compact(
            'members',
            'verticals',
            'specializations',
            'areas',
        ));
    }
}
